# Agenda Salão Analytics API
# Microserviço Python para analytics avançados