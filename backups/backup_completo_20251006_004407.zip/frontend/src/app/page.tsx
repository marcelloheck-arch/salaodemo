import MainApp from "@/components/MainApp";

export default function HomePage() {
  return <MainApp />;
}